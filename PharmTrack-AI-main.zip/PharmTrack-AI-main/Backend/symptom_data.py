symptom_map = {
    "fever": "High",
    "cough": "Persistent Cough",
    "headache": "Headache",
    "sore throat": "Sore Throat",
    "fatigue": "Extreme Tiredness",
    "cold": "Common Cold",
    "body pain": "Body Aches",
    "nausea": "Feeling Sick",
    "vomiting": "Vomiting",
    "diarrhea": "Loose Stools"
}
